extends Node3D

var game
var player
var cooldown = 0.0
var phase = 0.0
var muzzle: Node3D

func setup(p_game, p_player) -> void:
    game = p_game
    player = p_player
    _build_visual()

func _build_visual() -> void:
    var core = MeshInstance3D.new()
    var core_mesh = SphereMesh.new()
    core_mesh.radius = 0.32
    core_mesh.height = 0.64
    core.mesh = core_mesh
    core.material_override = game.make_material(Color("26344f"), 0.65, 0.3)
    add_child(core)

    var eye = MeshInstance3D.new()
    var eye_mesh = SphereMesh.new()
    eye_mesh.radius = 0.12
    eye_mesh.height = 0.24
    eye.mesh = eye_mesh
    eye.position = Vector3(0, 0.02, -0.28)
    eye.material_override = game.make_emissive_material(Color("58d7ff"), 3.0, 0.2)
    add_child(eye)

    var gun = MeshInstance3D.new()
    var gun_mesh = BoxMesh.new()
    gun_mesh.size = Vector3(0.12, 0.12, 0.55)
    gun.mesh = gun_mesh
    gun.position = Vector3(0.28, -0.05, -0.18)
    gun.material_override = game.make_material(Color("11161e"), 0.8, 0.2)
    add_child(gun)
    muzzle = Node3D.new()
    muzzle.position = Vector3(0.28, -0.05, -0.50)
    add_child(muzzle)

func _process(delta: float) -> void:
    if player == null or not is_instance_valid(player):
        return
    phase += delta
    cooldown = maxf(0.0, cooldown - delta)
    var offset = Vector3(cos(phase * 0.9) * 1.8, 2.1 + sin(phase * 2.1) * 0.14, sin(phase * 0.9) * 1.8)
    global_position = global_position.lerp(player.global_position + offset, clampf(delta * 4.0, 0.0, 1.0))
    var enemy = game.get_nearest_enemy(global_position, 13.5)
    if enemy != null and is_instance_valid(enemy):
        look_at(enemy.global_position + Vector3.UP * 0.65, Vector3.UP)
        if cooldown <= 0.0:
            cooldown = 0.52
            enemy.take_damage(player.damage * 0.28, false)
            game.spawn_tracer(muzzle.global_position, enemy.global_position + Vector3.UP * 0.6, Color("65ddff"))
