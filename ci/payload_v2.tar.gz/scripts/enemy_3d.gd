extends CharacterBody3D

signal died(archetype: String, where: Vector3, xp_value: int)

var game
var target
var archetype = "swarmer"
var max_health = 70.0
var health = 70.0
var move_speed = 4.4
var damage = 13.0
var attack_range = 1.35
var attack_interval = 0.85
var attack_cooldown = 0.5
var xp_value = 14
var dead = false
var elite = false
var visual_root: Node3D
var base_color = Color("7ddc4d")
var pulse = 0.0
var charge_timer = 0.0
var boss_phase = 1

func setup(p_game, p_target, p_kind: String, difficulty: float, p_elite = false) -> void:
    game = p_game
    target = p_target
    archetype = p_kind
    elite = p_elite
    collision_layer = 2
    collision_mask = 3
    _configure_stats(difficulty)
    _build_visual()

func _configure_stats(difficulty: float) -> void:
    match archetype:
        "hunter":
            max_health = 118.0
            move_speed = 5.8
            damage = 20.0
            attack_range = 1.45
            attack_interval = 1.05
            xp_value = 24
            base_color = Color("f08b37")
        "spitter":
            max_health = 92.0
            move_speed = 3.2
            damage = 17.0
            attack_range = 10.5
            attack_interval = 1.75
            xp_value = 22
            base_color = Color("b85bff")
        "brute":
            max_health = 330.0
            move_speed = 2.55
            damage = 34.0
            attack_range = 1.8
            attack_interval = 1.35
            xp_value = 52
            base_color = Color("d94343")
        "boss":
            max_health = 2600.0
            move_speed = 2.1
            damage = 42.0
            attack_range = 2.3
            attack_interval = 1.2
            xp_value = 420
            base_color = Color("7f23d9")
        _:
            max_health = 68.0
            move_speed = 4.5
            damage = 12.0
            attack_range = 1.25
            attack_interval = 0.78
            xp_value = 13
            base_color = Color("76d84f")
    max_health *= difficulty
    health = max_health
    damage *= 0.80 + 0.20 * difficulty
    if elite and archetype != "boss":
        max_health *= 1.85
        health = max_health
        damage *= 1.35
        move_speed *= 1.08
        xp_value = int(round(float(xp_value) * 2.2))

func _build_visual() -> void:
    var collider = CollisionShape3D.new()
    var shape = CapsuleShape3D.new()
    var radius = 0.42
    var height = 1.55
    if archetype == "brute":
        radius = 0.72
        height = 1.55
    elif archetype == "boss":
        radius = 1.45
        height = 3.2
    shape.radius = radius
    shape.height = height
    collider.shape = shape
    collider.position.y = height * 0.52
    add_child(collider)

    visual_root = Node3D.new()
    visual_root.position.y = height * 0.52
    add_child(visual_root)

    var body = MeshInstance3D.new()
    var mesh = SphereMesh.new()
    mesh.radius = radius
    mesh.height = radius * 2.0
    body.mesh = mesh
    body.scale = Vector3(1.25, 0.78, 1.5)
    body.material_override = game.make_material(base_color, 0.05, 0.85)
    visual_root.add_child(body)

    var head = MeshInstance3D.new()
    var head_mesh = SphereMesh.new()
    head_mesh.radius = radius * 0.58
    head_mesh.height = radius * 1.16
    head.mesh = head_mesh
    head.position = Vector3(0, radius * 0.20, -radius * 1.15)
    head.material_override = game.make_material(base_color.lightened(0.12), 0.0, 0.78)
    visual_root.add_child(head)

    for side in [-1.0, 1.0]:
        for row in [0.0, 1.0]:
            var leg = MeshInstance3D.new()
            var leg_mesh = BoxMesh.new()
            leg_mesh.size = Vector3(radius * 0.22, radius * 0.18, radius * 1.15)
            leg.mesh = leg_mesh
            leg.position = Vector3(side * radius * 0.9, -radius * 0.48, (row - 0.5) * radius * 0.85)
            leg.rotation_degrees.y = side * (28.0 + row * 14.0)
            leg.material_override = game.make_material(base_color.darkened(0.25), 0.1, 0.9)
            visual_root.add_child(leg)

    var eye_mat = game.make_emissive_material(Color("ffdf62") if archetype != "spitter" else Color("8cff8c"), 3.0, 0.2)
    for side in [-1.0, 1.0]:
        var eye = MeshInstance3D.new()
        var eye_mesh = SphereMesh.new()
        eye_mesh.radius = radius * 0.08
        eye_mesh.height = radius * 0.16
        eye.mesh = eye_mesh
        eye.position = Vector3(side * radius * 0.22, radius * 0.28, -radius * 1.65)
        eye.material_override = eye_mat
        visual_root.add_child(eye)

    if archetype == "spitter":
        var sac = MeshInstance3D.new()
        var sac_mesh = SphereMesh.new()
        sac_mesh.radius = radius * 0.55
        sac_mesh.height = radius * 1.1
        sac.mesh = sac_mesh
        sac.position = Vector3(0, radius * 0.45, radius * 1.0)
        sac.material_override = game.make_emissive_material(Color("61e878"), 1.8, 0.45)
        visual_root.add_child(sac)

    if elite or archetype == "boss":
        var crown = MeshInstance3D.new()
        var crown_mesh = TorusMesh.new()
        crown_mesh.inner_radius = radius * 0.60
        crown_mesh.outer_radius = radius * 0.82
        crown.mesh = crown_mesh
        crown.position.y = radius * 1.10
        crown.material_override = game.make_emissive_material(Color("ff486c") if elite else Color("b86bff"), 2.2, 0.35)
        visual_root.add_child(crown)

func _physics_process(delta: float) -> void:
    if dead or target == null or not is_instance_valid(target):
        return
    attack_cooldown = maxf(0.0, attack_cooldown - delta)
    pulse += delta
    charge_timer = maxf(0.0, charge_timer - delta)
    var to_target = target.global_position - global_position
    to_target.y = 0.0
    var dist = to_target.length()
    if dist > 0.15:
        look_at(Vector3(target.global_position.x, global_position.y, target.global_position.z), Vector3.UP)

    if archetype == "spitter":
        if dist > 8.0:
            velocity = to_target.normalized() * move_speed
        elif dist < 5.3:
            velocity = -to_target.normalized() * move_speed * 0.65
        else:
            velocity = Vector3.ZERO
        if dist <= attack_range and attack_cooldown <= 0.0:
            attack_cooldown = attack_interval
            game.spawn_acid_bolt(global_position + Vector3.UP * 0.75, target, damage)
    elif archetype == "hunter":
        var speed = move_speed
        if dist > 6.0 and charge_timer <= 0.0:
            speed *= 1.55
        velocity = to_target.normalized() * speed if dist > attack_range else Vector3.ZERO
        if dist <= attack_range and attack_cooldown <= 0.0:
            attack_cooldown = attack_interval
            charge_timer = 1.8
            target.take_damage(damage)
    elif archetype == "boss":
        velocity = to_target.normalized() * move_speed if dist > attack_range else Vector3.ZERO
        if dist <= attack_range and attack_cooldown <= 0.0:
            attack_cooldown = attack_interval
            target.take_damage(damage)
        if int(pulse * 10.0) % 43 == 0 and randf() < 0.055:
            game.explode_at(target.global_position, 3.4, damage * 0.48, Color("a84cff"), self)
    else:
        velocity = to_target.normalized() * move_speed if dist > attack_range else Vector3.ZERO
        if dist <= attack_range and attack_cooldown <= 0.0:
            attack_cooldown = attack_interval
            target.take_damage(damage)
    velocity.y = -0.2
    move_and_slide()

    if visual_root != null:
        visual_root.position.y += sin(pulse * 8.0) * 0.0008

func take_damage(amount: float, critical = false) -> void:
    if dead:
        return
    health -= amount
    game.spawn_damage_number(global_position + Vector3.UP * 1.25, amount, critical, false)
    game.spawn_hit_spark(global_position + Vector3.UP * 0.8, Color("fff08a") if critical else base_color.lightened(0.4), critical)
    if archetype == "boss" and health > 0.0:
        var ratio = health_ratio()
        var next_phase = 1
        if ratio <= 0.66:
            next_phase = 2
        if ratio <= 0.33:
            next_phase = 3
        if next_phase > boss_phase:
            boss_phase = next_phase
            game.on_boss_phase(self, boss_phase)
    if health <= 0.0:
        _die()

func _die() -> void:
    if dead:
        return
    dead = true
    collision_layer = 0
    game.spawn_death_burst(global_position + Vector3.UP * 0.5, base_color, archetype == "boss")
    died.emit(archetype, global_position, xp_value)
    queue_free()

func health_ratio() -> float:
    return 0.0 if max_health <= 0.0 else clampf(health / max_health, 0.0, 1.0)
